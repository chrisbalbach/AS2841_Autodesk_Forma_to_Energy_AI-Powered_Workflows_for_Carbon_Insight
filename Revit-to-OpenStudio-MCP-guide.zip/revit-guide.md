# Revit → EnergyPlus: a guide for Revit users

Take a building you already modeled in Revit and get it running in EnergyPlus, without writing a
line of code. You will export a gbXML, gather three weather files, hand all four to an AI
assistant, and let it drive the OpenStudio tools for you.

*Verified against openstudio-mcp commit `b53dfe5`. Sections marked 🟣 are not derived from this
repository — see [Appendix E](#appendix-e--things-that-change).*

> **Read this before you start.** This workflow produces a geometry-and-location model with default
> everything. A simulation that finishes is not a simulation that is right — see
> [§8](#8-before-you-believe-any-number), which exists specifically because several checks in this
> pipeline report success on a model that is thermally wrong. Nothing here is suitable for code
> compliance, LEED, or a client deliverable without an energy modeler reviewing it. See
> [DISCLAIMER.md](../DISCLAIMER.md).

---

## 0. How this actually works

You will be talking to Claude Code. Claude Code talks to the openstudio-mcp server, which runs
inside a Docker container. **The server cannot see your hard drive.** It sees only the folders you
explicitly share with it.

```
   Your PC                          The server (inside Docker)
   -------                          --------------------------
   C:\OSMCP\inputs\  ---shared-->   /inputs    (read-only - you put files here)
                                    /runs      (writable - results come out here)
```

Two consequences that cause most first-day failures:

- **Server paths are not your paths.** A file at `C:\Projects\Tower\tower.xml` does not exist as far
  as the server is concerned. Put it in your shared folder and it becomes `/inputs/tower.xml`, which
  is the path every tool understands. If you paste a `C:\...` path into the chat, the tool will tell
  you the path is server-side and list the roots it can actually read.
- **Do not drag files into the chat window.** Chat attachments go into a separate analysis sandbox
  that cannot reach the MCP tools at all. The assistant will fall back to writing scripts instead of
  using the purpose-built tools. Always use the shared folder.

---

## 1. Choose your track

> **Did someone hand you a server address and a token?** → **Track B**.
> **Otherwise** → **Track A** (you run it yourself).

---

## 1A. Track A — run it locally with Docker

### A1. Install Docker Desktop

Install [Docker Desktop](https://www.docker.com/products/docker-desktop/) and start it. On Windows
it will set up WSL2 for you; you may need an administrator for that step.

> 🔴 **Docker Desktop must be running every time you use this.** The whale icon must be in your
> system tray. The server is launched on demand — it is not a background service, and if Docker is
> not running the tools simply will not appear.

### A2. Get the code and build the image

```bash
git clone https://github.com/NatLabRockies/openstudio-mcp.git
cd openstudio-mcp
docker build -t openstudio-mcp:dev -f docker/Dockerfile .
```

On Apple Silicon use `docker build --platform linux/arm64 -t openstudio-mcp:dev -f docker/Dockerfile.arm64 .`
instead. This takes a while the first time.

### A3. Decide which folder becomes `/inputs`

You choose this once, now, during installation. Whatever folder you pick is what the server sees as
`/inputs`, and it is where your four files have to go.

**Option 1 — keep the default.** Out of the box, `/inputs` points at `tests/assets` inside the repo
you just cloned. This works immediately with no decision to make: you drop your four files into
`…/openstudio-mcp/tests/assets` and they appear to the server as `/inputs/…`, alongside the
project's own test models.

**Option 2 — point it at a folder of your own**, for example `C:\OSMCP\inputs`. Worth doing for real
project work:

- your models stay out of the repository, so a `git pull` or a fresh clone never disturbs them, and
  you never risk committing a client's building
- the folder can live wherever your projects already live
- `/inputs` contains your files and nothing else, so listings are readable

Either way, note which folder you chose — every path you give the assistant resolves against it.

### A4. Tell Claude Code about the server

Create a file named `.mcp.json` in the folder where you will run Claude Code:

```json
{
  "mcpServers": {
    "openstudio-mcp": {
      "command": "docker",
      "args": [
        "run", "--rm", "-i",
        "-v", "C:/OSMCP/openstudio-mcp/tests/assets:/inputs:ro",
        "-v", "C:/OSMCP/openstudio-mcp/runs:/runs",
        "-v", "C:/OSMCP/openstudio-mcp/measures:/measures",
        "-v", "C:/OSMCP/openstudio-mcp/.claude/skills:/skills:ro",
        "-e", "OPENSTUDIO_MCP_MODE=prod",
        "openstudio-mcp:dev", "openstudio-mcp"
      ]
    }
  }
}
```

That first mount is the one you decided on in A3. The block above shows the **default** — `/inputs`
pointing at `tests/assets` inside the repo. If you chose a folder of your own, replace the left-hand
side of that line only:

```json
"-v", "C:/OSMCP/inputs:/inputs:ro",
```

Three things to get right:

> 🔴 **Use forward slashes.** `C:/OSMCP/inputs`, never `C:\OSMCP\inputs`. A backslash either breaks
> the JSON outright (and your server never appears) or Docker silently treats the string as a
> *volume name* and mounts an empty folder. Both look identical from the chat: "the file isn't
> there."

> 🟡 **Remember which folder you chose.** Files have to go in *that* folder to be visible as
> `/inputs`. If you kept the default and put your gbXML somewhere else, every path you try comes back
> "not found" — the mount is fine, the file just isn't in it.

> 🟡 **The other three paths point into your cloned repo.** Use the absolute path to wherever you ran
> `git clone`.

If the block above ever disagrees with the one in the
[repository README](../README.md#quick-start-local), **the README wins** — it changes more often
than this guide does.

Restart Claude Code after saving the file.

> **✓ Checkpoint A** — `docker images` lists `openstudio-mcp:dev`, and in Claude Code, asking *"list
> your openstudio tools"* returns a list that includes `import_gbxml` and `run_simulation`.
> *Means: the image built and your client can launch it.*
> Didn't see that? → [Appendix A](#appendix-a--troubleshooting-by-symptom)

---

## 1B. Track B — connect to a shared server

### B1. What your administrator gives you

A URL (like `http://192.168.4.20:8000/mcp`) and a bearer token. If you do not have both, stop and
ask for them — there is nothing you can do from your side.

### B2. Add the config

Create `.mcp.json` in the folder where you run Claude Code:

```json
{
  "mcpServers": {
    "openstudio-mcp": {
      "type": "http",
      "url": "http://192.168.4.20:8000/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN_HERE"
      }
    }
  }
}
```

Restart Claude Code.

If you cannot reach it: the server must allow inbound TCP 8000 through its firewall, and you must be
on the same network. `localhost` in the URL only works if the server is on your own machine. See
[docs/remote-multi-user.md](remote-multi-user.md).

### B3. Getting your four files onto the server

This is where Track B genuinely differs, and there is a trap.

**Best option: ask your administrator to stage your files under `/inputs` on the server.** Then the
rest of this guide reads identically to Track A.

**If you must upload them yourself**, the assistant will use the upload tools for you — but each
uploaded file lands in **its own separate directory**. That breaks a hard requirement of the import
step ([§4](#4-get-the-weather-files)), which needs the three weather files sitting together.

> 🔴 **Zip the three weather files into one archive and upload the zip.** Any `.zip` is
> automatically extracted server-side into a single directory, so `.epw`, `.stat` and `.ddy` land
> together where the importer can find them. Uploading them as three separate files will fail.

Upload the gbXML on its own — it has no companions.

> **✓ Checkpoint B** — asking *"list your openstudio tools"* returns the tool list with no
> authorization error. *Means: the URL is reachable and your token was accepted.*

---

## 2. Both tracks meet here

Ask Claude Code:

> "What files can you see in /inputs?"

You should get a directory listing — even an empty one is fine at this stage. An **error** here is a
mount problem, not a file problem; go back to [§1A](#1a-track-a--run-it-locally-with-docker).

This guide is written for **Claude Code**. Other MCP clients work to varying degrees; see the
compatibility table in the [README](../README.md#client-compatibility) and be aware that clients
with tool-count caps will silently hide tools you need.

---

## 3. Export gbXML from Revit

> 🟣 **This section is not derived from the openstudio-mcp repository.** Menu paths and option names
> move between Revit releases. Treat it as a starting point and confirm against your own
> installation. The repository's own examples are written against **Revit 2022+**.

### 3a. Prepare the model first

Most import failures are export failures. Before you export:

- **Place Spaces (or Rooms) that bound every conditioned volume.** The translator cannot invent an
  enclosure that Revit never exported. Empty or unbounded areas come through as nothing at all.
- **Check every space reports a non-zero volume in Revit.** A space with no computed volume becomes
  a zone with no volume, which corrupts equipment autosizing downstream — and you will see it later
  as `zero_volume_zone_count`.
- **Make sure space upper limits and offsets reach the floor above.** Spaces that stop short leave
  gaps the geometry repair tools then have to guess at.
- **Turn on volume computation** in Area and Volume Computations.

### 3b. Inspect the Energy Analytical Model before you export

**This is the highest-value half hour in the whole workflow.** Revit generates the Energy Analytical
Model (EAM) from your building elements, and the gbXML is a dump of the EAM — not of your Revit
geometry. Whatever is wrong in the EAM is wrong in the gbXML, and by the time you see it downstream
it costs a re-export at best and hours of geometry repair at worst.

Generate the analytical model, then open a 3D view with analytical surfaces and analytical spaces
visible. Work through the surfaces and subsurfaces visually, and check the properties of anything
that looks wrong.

**What to check, and what each one costs you if you skip it:**

| In Revit, look for | Downstream consequence |
|---|---|
| **Slabs at grade typed as slab-on-grade / underground**, not as an interior floor or exterior wall | Misclassified slabs arrive as `Outdoors` and take fictitious solar gain and wind convection. This is the `ground_contact_missing_count` problem in [§8](#8-before-you-believe-any-number) — the repository's own basement fixture ends up with **1 ground surface out of 292**. |
| **Below-grade walls typed as underground wall** | Same — a buried wall left exterior is heated and cooled by weather it never sees. |
| **Interior surfaces typed as interior**, with the adjacent analytical space actually named | A partition misclassified as exterior becomes an exterior wall with full solar exposure. A surface with no adjacency arrives unpaired and drives the repair loop in [§7](#7-repair-the-geometry). |
| **Roofs typed as roof**, not as exterior wall | Wrong construction, wrong solar orientation, wrong sizing. |
| **Every analytical space has a non-zero volume and area** | `zero_volume_zone_count` — corrupts autosized equipment capacities. |
| **No holes in the envelope** — every space has a floor and a ceiling/roof | `non_enclosed_spaces_count`, the count you will spend [§7](#7-repair-the-geometry) trying to drive to zero. A missing ceiling is the single most common cause. |
| **Walls that read as one surface, not a mosaic of slivers** | Revit splitting one physical wall into many coplanar fragments is a distinct repair step of its own (merge coplanar slivers). |
| **No missing interior partitions** — especially in repeated unit types, where the same wall tends to be dropped from every stacked instance | The patcher reconstructs them and, when it cannot identify what they are, sets them **Adiabatic** — zero heat flux. On the repository's own fixture that is **103 of 117 patches**. Every one of those is an assumption you did not make. |
| **No duplicated shared walls** — one wall between two rooms, not one per room | Overlapping surfaces, needing the trim step. |
| **Windows and doors present on the analytical surfaces**, with a plausible window-to-wall ratio per facade | Subsurfaces that did not make it into the EAM are simply absent from the energy model. Nothing downstream can tell you they should have been there. |
| **Curtain walls resolved into analytical openings**, not one undivided panel or nothing at all | Wrong glazing area, wrong solar gain, silently. |
| **No windows landing on interior surfaces** | Physically incoherent; blocks the trim step, which refuses to touch any surface carrying a window or door. |
| **Thermostats / HVAC information present** if your workflow expects it | With no thermostats, `conditioned_zone_count` comes back **0** — and then every downstream check is vacuously clean while the simulation reports near-zero HVAC energy. See [§8](#8-before-you-believe-any-number). |
| **Shading elements** — overhangs, fins, adjacent massing — included where they matter | Understated or overstated cooling loads, with nothing to flag it. |

> 🟣 **The Revit half of this table is practice, not repository-derived.** Analytical model behavior
> and the exact property names vary by Revit version. The *downstream consequences* in the right-hand
> column are all verified against this repository, so use those as the reason to look.

> 🔵 **Why bother, when [§7](#7-repair-the-geometry) can repair geometry anyway?** Because the repair
> tools are explicitly not guaranteed to converge, and because several of them resolve ambiguity by
> *assuming* — Adiabatic surfaces, inherited constructions. A defect fixed in Revit is a fact; the
> same defect fixed downstream is a guess that your results then rest on.

### 3c. Export

File → Export → gbXML. Choose the detailed / room-and-space-based export rather than a conceptual
mass export — the import measures expect per-surface geometry.

### 3d. Find what Systems Analysis wrote

Running Systems Analysis writes its working data into your Windows **TEMP** directory. Each run
gets its **own uniquely-named folder** — and the file inside is always called `gbXML.xml`. What
distinguishes one run from another is the folder, not the filename.

```
%TEMP%\
  ├─ RevitSystemsAnalysis\ ...\gbXML.xml    ← one folder per run
  └─ RevitWeatherFilesCache\                ← the weather files (see §4)
```

**Find the right one by timestamp.** Rather than working out the folder naming, search for the file
and sort by time: in [voidtools Everything](https://www.voidtools.com/), search `gbXML.xml`, turn on
the Date Modified column, and sort by it. The run you want is the one whose timestamp matches when
you kicked off the analysis in Revit — usually the top result.

> 🔴 **Rename it before you stage it.** Every run produces a file called `gbXML.xml`. Two of them in
> your inputs folder collide, and nothing in the filename tells you which building or which run it
> came from. Rename it on the way out — `Tower_2026-03-11.xml`, not `gbXML.xml`.

### 3e. What a reasonable export looks like

Open the `.xml` in a text editor and search for `<Space`. The count should be in the same ballpark
as the number of rooms you expect. A file of a few hundred KB or more for a real building is normal;
a few KB means almost nothing was exported.

> **✓ Checkpoint 3** — you have a `.xml` file whose `<Space>` count roughly matches your room count.
> *This is a self-check, not a server check — nothing has touched the server yet.*

**Expect imperfection.** A substantial fraction of real Revit exports need geometry repair, and some
need to be re-exported. [§7](#7-repair-the-geometry) is where that happens; it is a normal part of
the workflow, not a sign you did something wrong.

---

## 4. Get the weather files

You need **three** weather files, not one: `.epw`, `.stat` and `.ddy`.

| File | What it does |
|---|---|
| `.epw` | Hourly weather. Its location is embedded in the resulting model. |
| `.stat` | Climate statistics — this is what supplies the ASHRAE climate zone. |
| `.ddy` | Design-day definitions — these drive HVAC equipment sizing. |

All three are required. The importer fails immediately without them, even though it never runs a
simulation.

### 4a. Finding the files Revit already downloaded

Revit caches the weather data it downloaded for your project location in your Windows **TEMP**
directory, in a folder named `RevitWeatherFilesCache` — sitting alongside the
`RevitSystemsAnalysis` folder your gbXML came from ([§3c](#3d-find-what-systems-analysis-wrote)):

```
%TEMP%\
  ├─ RevitSystemsAnalysis\
  └─ RevitWeatherFilesCache\    ← .epw, .stat, .ddy
```

Paste `%TEMP%` into the Explorer address bar, or search for the folder name with
[voidtools Everything](https://www.voidtools.com/). Confirm all three files came from the **same
station** before you copy them out.

> 🟣 **Author practice, not repository-derived.** This is where Revit puts them today. Folder names
> and behavior can change between Revit releases — if the folder isn't there, fall back to §4b.
> Because it is a *cache* in TEMP, treat it as disposable: copy the files out to your inputs folder,
> don't reference them in place.

### 4b. If Revit didn't give you all three

Download a complete set instead. Weather repositories generally offer a **zip** per station that
contains all three files — take the zip, not the standalone EPW link.

> 🟣 **Unverified.** We cannot promise any particular source ships a `.ddy`, or that all three files
> in a given download share a filename. Whatever the source, the rule below is what the server
> actually enforces.

### 4c. The rule that will bite you

> 🔴 **All three weather files must sit in the same folder and have identical names apart from the
> extension.**

```
GOOD:  Tower.epw   Tower.stat   Tower.ddy          (same folder)

BAD:   weather\boston.epw   +   boston_TMY3.stat   (different stems)
BAD:   weather\boston.epw   +   ddy\boston.ddy     (different folders)
```

The importer does not search for the companions. It takes the EPW's path and swaps the extension —
nothing more. If the result isn't there, you get:

```
Missing companion .stat file next to EPW: /inputs/weather/boston.stat
```

Rename the files so their stems match. The names themselves don't matter.

---

## 5. Put the four files where the server can see them

Copy all four into whichever folder you chose in [§1A3](#a3-decide-which-folder-becomes-inputs).
On the default configuration that is `…/openstudio-mcp/tests/assets`; the table below assumes you
picked a folder of your own.

| You see (Windows) | The server sees |
|---|---|
| `C:\OSMCP\inputs\Tower.xml` | `/inputs/Tower.xml` |
| `C:\OSMCP\inputs\Tower.epw` | `/inputs/Tower.epw` |
| `C:\OSMCP\inputs\Tower.stat` | `/inputs/Tower.stat` |
| `C:\OSMCP\inputs\Tower.ddy` | `/inputs/Tower.ddy` |

On Track B, this is where your administrator's staging (or your zip upload) has already put them.

> **✓ Checkpoint 5 — the most valuable check in this guide.** Ask:
> *"What's in /inputs?"*
> All four filenames appear, and the `.epw`, `.stat` and `.ddy` share an identical stem.
> *Means: the server can read exactly what the importer is about to ask for.* This catches the
> naming failure before it turns into a cryptic error twenty minutes from now.

---

## 6. Import the gbXML

Ask Claude Code:

> "Import the gbXML at /inputs/Tower.xml using the weather file /inputs/Tower.epw."

Behind that, `import_gbxml` runs six measures in sequence — location, geometry, advanced geometry,
HVAC, simulation control, postprocess — with EnergyPlus deliberately switched off. The resulting
model is loaded into your session automatically.

> 🟡 **This is one long blocking call.** The project's own small test fixture takes roughly 3
> minutes on a fast local machine and up to 8.5 minutes on a slow one. A real building is larger. If your client reports a timeout,
> **the import may still be running inside the container** — ask what's in `/runs` and look for a new
> `gbxml_import_*` directory before you try again. Re-issuing starts a second CPU-bound import
> alongside the first.
>
> We deliberately give no time estimate for a building of a given size. We have one measurement, on
> one fixture, on one machine.

### 6a. Read the import report

| Field | What to look for |
|---|---|
| `ok` | `true` |
| `total_errors` | `0`. Warnings are normal; errors are not. |
| `osm_path` | Where your model was saved — a **server** path under `/runs/`. |
| `climate_zone` | Populated, and matching the zone you know the project is in. |
| `climate_zone_source` | `gbxml_measure`, `stat_file`, or `wmo_or_geographic_lookup`. |
| `climate_zone_resolved` | If `false`, see below. |
| `conditioned_zone_count` | Compare against your expected room count — see [§8](#8-before-you-believe-any-number). |
| `zero_volume_zone_count` | `0`. Anything else means Revit exported spaces with no volume. |

`step_messages` breaks errors out per measure, so a failure inside the HVAC step is distinguishable
from one in the geometry step.

**If `climate_zone_resolved` is `false`,** ask the assistant to set the location explicitly using
the weather file and looking the zone up from the stat file, before doing any ASHRAE 90.1 work. The
import itself still succeeded.

---

## 7. Repair the geometry

Ask:

> "Validate and repair the gbXML geometry."

This runs `repair_and_validate_gbxml_geometry()`, which fixes shared walls left as "Outdoors",
re-synchronizes mismatched interior surface pairs, and then reports what it could not fix:
`non_enclosed_spaces_count`, `overlapping_surfaces_count`, and others.

**Non-zero counts on a first Revit export are normal.** Write the starting numbers down.

If the counts aren't zero, there are five distinct causes, each needing a different repair, and they
must be worked in this order:

1. **Missing roof or ceiling entirely** → repair missing roof/ceiling
2. **Fragmented surfaces** (Revit split one wall into many slivers) → merge coplanar slivers
3. **Sub-centimetre corner gaps** → weld coincident vertices
4. **A surface missing outright** → patch missing surfaces
5. **Same-space overlap / duplicated shared walls** → trim overlapping surfaces

Merge and weld run before patch and trim — patch and trim work off whatever gap is left after the
first two have closed what they can.

> 🔴 **Re-validate after every single repair.** Not at the end — after each one. The repair tools
> each rewrite one side of an interior surface pair in isolation, and a pair whose two sides
> disagree makes EnergyPlus abort at `GetSurfaceData` before it simulates anything. Re-validating is
> what re-synchronizes those pairs. Nothing else in this server catches it — not even
> `validate_model`.

> 🔴 **Know when to stop.** These tools do not guarantee closure, and patch and trim can oscillate
> against each other on ambiguous geometry — each pass recreates the other's input. **If two
> consecutive validations do not reduce `non_enclosed_spaces_count`, stop repairing and go fix the
> export in Revit.** No amount of further repair will close it.

> 🟡 **Save your work as you go.** Ask the assistant to save the model after each successful repair.
> The repair tools operate on the model held in memory, and the server drops it after 30 minutes
> idle. Note the side effect in [§8](#8-before-you-believe-any-number): reloading a saved model
> turns off one of the cross-checks.

> **✓ Checkpoint 7** — `non_enclosed_spaces_count: 0` and `overlapping_surfaces_count: 0`.
> *Means: the model is enclosed and can be simulated.* It does **not** mean the model is correct.

---

## 8. Before you believe any number

**Only three of the fields below affect `ok`.** The rest will let a thermally wrong model sail
through while every tool reports success. Go through all nine before you run anything.

They come from three different reports: the first two and the last from the **import** report
([§6a](#6a-read-the-import-report)); the middle four from the **validate-and-repair** report
([§7](#7-repair-the-geometry)); and the two construction-related ones only from the **patch
missing surfaces** step, if you ran it. Ask the assistant for whichever you haven't seen.

| Check | Why it matters |
|---|---|
| `conditioned_zone_count` | **The most dangerous false-green.** A zone only counts as conditioned if it has a thermostat. If your gbXML carried no HVAC information, this is `0` — and then `zero_volume_zone_count: 0` is *vacuously* clean, space-type assignment silently does nothing, and your simulation returns near-zero HVAC energy. If this is 0, or far below your room count, **stop**. |
| `zero_volume_zone_count` | Non-zero means Revit exported spaces with no volume. Autosized capacities will be wrong. Fix it in Revit. |
| `non_enclosed_spaces_count` | Must be 0. (Affects `ok`.) |
| `gbxml_deltas_checked` | The check that compares each space's area and volume against what Revit declared **only runs if the model is still the one the importer produced.** Saving and reloading — which §7 tells you to do — turns it off. If this is `false`, an empty delta result means nothing was checked, not that nothing is wrong. |
| `ground_contact_missing_count` | Does **not** affect `ok`. gbXML exports routinely under-declare ground contact — the repository's own basement fixture arrives with 1 ground surface out of 292. A buried slab left as "Outdoors" takes fictitious solar gain and wind. Ask for these to be set to Ground in one batch — but **review the list first**: a slab over a crawlspace or open parking is not ground contact. |
| ground temperatures | A translated model sets no ground temperature objects at all, so EnergyPlus defaults to 18 °C every month — in Boston and in Austin alike. Ask the assistant to set them from the project EPW. For real slab-edge heat transfer, use Kiva instead (see the `foundation-modeling` skill). |
| `ambiguous_boundary_condition_count` | Any surface the patcher reconstructed but could not pair is set **Adiabatic** — zero heat flux. That is an assumption, not a determination, and it is wrong for a genuinely exterior wall the export dropped. On the repository's own fixture this is **103 of 117 patches**. Review them and override the exterior ones. |
| `construction_fallback_count` | Patches inherit a construction from nearby geometry. `type_only_fallback` means the only donor available had a *different* boundary condition — so an exterior assembly may now be sitting on an interior surface. |
| `climate_zone_source` | `wmo_or_geographic_lookup` is a nearest-station guess, and `climate_zone_resolved` is still `true`. A wrong zone means wrong ASHRAE 90.1 envelope requirements later, with no warning anywhere. Confirm the zone against what you know the project's zone to be. |

Also worth knowing: `paired_area_mismatches` is reported but never fixed. Two sides of the same wall
with different areas is physically incoherent, and EnergyPlus accepts it without complaint.

---

## 9. Run your first simulation

**Treat this as a "does it run" test, not an answer.** A gbXML import gives you geometry and a
location. It does not give you realistic internal loads, schedules, or HVAC. Before the numbers mean
anything, your spaces need standards space types — see [§10](#10-where-to-go-next).

Ask:

> "Validate the model, then run a simulation using /inputs/Tower.epw."

The run is asynchronous — you get a run ID back, not results. The assistant will poll for status and
tell you when it finishes.

**If it fails**, ask for the simulation errors. The common ones:

- A fatal at `GetSurfaceData` means an interior surface pair is still desynchronized. Go back and
  re-run the validate-and-repair step.
- A truncated error file with no clear cause can be Docker running out of memory — raise the memory
  limit in Docker Desktop's settings.

**If it succeeds**, ask for the summary metrics. You will get a site EUI and end-use breakdown.

> **✓ Checkpoint 9** — status `success`, artifacts include an `.sql` and an HTML report, and you
> have an EUI number. *You have completed a Revit → EnergyPlus run.*
>
> That number is not yet meaningful. Continue to §10.

---

## 10. Where to go next

- **Assign standards space types** — the single most important next step. See the
  `attribute-space-types` skill and [example 23](examples/23_attribute_space_types.md).
- **Ground and foundation heat transfer** — EPW ground temperatures, or Kiva for real slab-edge heat
  transfer. See the `foundation-modeling` skill and
  [example 25](examples/25_ground_and_foundation_heat_transfer.md).
- **Add HVAC** — see the `add-hvac` and `ashrae-baseline-guide` skills.
- **Quality checks** — the `qaqc` skill.

Ask the assistant to `list_skills()` to see everything available.

---

## Appendix A — troubleshooting by symptom

| Symptom | Cause | Fix |
|---|---|---|
| `Missing companion .stat file next to EPW: ...` | `.stat` not beside the `.epw`, or a different stem | [§4c](#4c-the-rule-that-will-bite-you) |
| `Missing companion .ddy file next to EPW: ...` | Same | [§4c](#4c-the-rule-that-will-bite-you) |
| A file you can see in Explorer is "not found" | You gave a host path, not a server path | [§0](#0-how-this-actually-works), [§5](#5-put-the-four-files-where-the-server-can-see-them) |
| No openstudio tools appear at all | Docker not running, bad JSON, or client not restarted | [§1A](#1a-track-a--run-it-locally-with-docker) |
| Tools appear but some are missing | Your MCP client caps the tool count | [README compatibility table](../README.md#client-compatibility) |
| `/inputs` listing shows unfamiliar models | Expected on the default config — those are the project's test models | Put your files in `tests/assets` too, or repoint the mount ([§1A3](#a3-decide-which-folder-becomes-inputs)) |
| `/inputs` listing is empty when the folder isn't | Backslashes in the `-v` argument created an empty volume | [§1A4](#a4-tell-claude-code-about-the-server) |
| Import appears to hang, then times out | Normal for a real building | [§6](#6-import-the-gbxml) — check `/runs` before retrying |
| `climate_zone_resolved: false` | Climate zone could not be read from the stat file | [§6a](#6a-read-the-import-report) |
| `non_enclosed_spaces_count` won't reach 0 | Patch and trim oscillating | [§7](#7-repair-the-geometry) — stop and re-export |
| Simulation fatals at `GetSurfaceData` | Desynchronized interior surface pair | [§7](#7-repair-the-geometry) — re-validate |
| "No model loaded" partway through | Session dropped after 30 minutes idle | [§7](#7-repair-the-geometry) — save as you go |
| Uploaded weather files still rejected | Each upload landed in its own directory | [§1B3](#b3-getting-your-four-files-onto-the-server) — zip them |
| Server unreachable from another PC | Firewall blocking inbound TCP 8000 | [Appendix B](#appendix-b--for-administrators) |

---

## Appendix B — for administrators

Standing up a shared HTTP server, issuing tokens, session and concurrency limits, and firewall
setup are covered in [docs/remote-multi-user.md](remote-multi-user.md).

Two Windows gotchas worth repeating:

- `MCP_TOKENS` must be passed via `$env:`, not inline with `-e` — PowerShell mangles the embedded
  quotes, the JSON arrives malformed, and the server fails closed with what looks like a bad token.
- Open inbound TCP 8000 with `New-NetFirewallRule`, or clients hang with no error at all.

By default only one simulation runs at a time, so a colleague's annual run will leave yours
`queued` with no estimate.

---

## Appendix C — manual file transfer

If you need to move files yourself rather than asking the assistant, see the `file-transfer` skill
and [docs/remote-multi-user.md](remote-multi-user.md).

> 🟡 **On Windows, type `curl.exe`, not `curl`.** Bare `curl` in PowerShell is an alias for
> `Invoke-WebRequest`, a different program that will reject `--upload-file` and `-O -J`. The bundled
> instructions show the bare form, so the assistant may hand you a command that needs this fix.

---

## Appendix D — paths and permissions

| Path | Access | What it holds |
|---|---|---|
| `/inputs` | read-only | Files you stage for the server |
| `/runs` | read/write | Simulation outputs, imported models |
| `/measures` | read/write | Your authored and downloaded measures |
| `/skills` | read-only | Workflow guides available via `list_skills()` |

Anything outside these is denied. On a shared server each user gets their own isolated area under
`/runs` and `/measures`. Details in [docs/security-isolation.md](security-isolation.md).

---

## Appendix E — things that change

These are the parts of this guide most likely to go stale. If something here doesn't match what you
see, distrust this guide before you distrust the software.

- **Everything in [§3](#3-export-gbxml-from-revit) (Revit export).** Not derived from this
  repository at all. Autodesk reorganizes the energy settings and gbXML export dialog between
  releases.
- **The TEMP folder names** — `RevitSystemsAnalysis` and `RevitWeatherFilesCache`
  ([§3c](#3d-find-what-systems-analysis-wrote), [§4a](#4a-finding-the-files-revit-already-downloaded)).
  Current author practice. These are cache folders, so both their names and their contents are
  Autodesk's to change.
- **[§4b](#4b-if-revit-didnt-give-you-all-three) — weather download sources.** Site structures churn.
  The same-stem rule in §4c is what the server enforces and is stable.
- **[§1A4](#a4-tell-claude-code-about-the-server) — the config block.** Mounts and environment
  variables get added over time. The [README](../README.md#quick-start-local) is the source of truth.
- **Field names throughout.** Several of the fields in [§8](#8-before-you-believe-any-number) are
  recent additions. If a name doesn't match, the underlying concern still applies — ask the
  assistant what it reports.
- **Import duration.** The only measurement that exists is for one small test fixture on one
  machine.

---

## Appendix F — glossary

| Term | Meaning |
|---|---|
| **gbXML** | Green Building XML — the geometry interchange format Revit exports |
| **EPW** | EnergyPlus Weather — hourly weather data for a location |
| **DDY** | Design Day — extreme conditions used to size HVAC equipment |
| **STAT** | Statistics file accompanying an EPW; supplies the ASHRAE climate zone |
| **OSM** | OpenStudio Model — the format everything downstream works in |
| **MCP** | Model Context Protocol — how Claude Code talks to the OpenStudio server |
| **Bind mount** | A folder on your PC made visible inside the Docker container |
| **Thermal zone** | A group of spaces controlled by one thermostat |
| **Adiabatic** | A surface assumed to pass no heat at all |
