Revit to EnergyPlus — user guide bundle
=======================================

Contents
--------

revit-guide.html   The interactive guide. Double-click to open in any browser.
                   Self-contained: all CSS, JavaScript and diagrams are inside
                   this one file. Nothing else is required to render it.

revit-guide.pdf    A static 23-page print rendering of the same guide, for
                   handing to someone who won't open a browser, or for marking
                   up. Both install tracks and all collapsed sections are
                   expanded in the PDF.

revit-guide.md     The Markdown source. This is the version that lives in the
                   openstudio-mcp repository at docs/revit-user-guide.md and
                   is the one to edit if you want the guide's content changed.


About the HTML version
----------------------

Works offline. The only external request it makes is to Google Fonts; if that
is blocked or you are offline, the page falls back to Helvetica / Georgia /
Consolas and remains fully readable.

Interactive features (these are why the HTML is worth using over the PDF):

  - Track switcher. Pick "Local Docker" or "Shared server" once and the guide
    hides the track you are not on.
  - Path personalizer in step 01A3. Type your own folder paths and every code
    block and path table on the page rewrites itself to match. It also warns
    you if you type a backslash, which is the most common Windows setup error.
  - Checkpoint tick-boxes that drive the progress bar in the sidebar.
  - Copy buttons on every code block.
  - Light/dark theme, following your system setting by default.

Your track choice, ticked checkpoints and typed paths are remembered in that
browser only. They are not shared with anyone and do not travel with the file.


Status of the content
---------------------

Verified against openstudio-mcp commit b53dfe5.

Everything describing the openstudio-mcp server — tool names, return fields,
the weather-file naming rule, the failure modes in step 08 — was checked
against the source code.

The Revit-side material (step 03, and the TEMP folder locations in 03d/04a) is
practice, not repository-derived, and is marked as such in the guide. Revit
changes these between releases. Appendix E lists everything expected to go
stale first.

This workflow produces a geometry-and-location model with default everything.
A simulation that completes is not a simulation that is correct — see step 08.
Not suitable for code compliance, LEED, or client deliverables without review
by an energy modeler.
